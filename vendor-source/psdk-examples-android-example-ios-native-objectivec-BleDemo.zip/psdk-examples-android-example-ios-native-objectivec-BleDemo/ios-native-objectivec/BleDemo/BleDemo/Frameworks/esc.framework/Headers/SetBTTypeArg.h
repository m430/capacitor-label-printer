//
//  SetBTTypeArg.h
//  ESC
//
//  Created by aiyin on 2022/4/22.
//

#import <father/OnlyBinaryHeaderArg.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * 设置蓝牙类型
 */
@interface SetBTTypeArg : OnlyBinaryHeaderArg

@end

NS_ASSUME_NONNULL_END

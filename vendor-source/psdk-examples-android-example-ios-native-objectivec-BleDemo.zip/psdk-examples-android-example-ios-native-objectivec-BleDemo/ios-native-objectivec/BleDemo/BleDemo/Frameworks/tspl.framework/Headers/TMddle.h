//
//  TMddle.h
//  TSPL
//
//  Created by IPRT on 2022/10/12.
//

#import<father/OnlyTextHeaderArg.h>

NS_ASSUME_NONNULL_BEGIN

@interface TMddle : OnlyTextHeaderArg

@end

NS_ASSUME_NONNULL_END
